export type envelope = {
  minX: number;
  maxX: number;
  minY: number;
  maxY: number;
};
