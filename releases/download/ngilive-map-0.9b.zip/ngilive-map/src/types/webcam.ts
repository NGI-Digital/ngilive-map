// Defines type webcam that is used before and after projetion
export type webcam = {
  name: string;
  coord: number[];
  coordSystem: string;
  webcamurl: string;
};
