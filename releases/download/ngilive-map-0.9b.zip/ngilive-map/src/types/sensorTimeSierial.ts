export type sensorTimeSerial = {
  values: number[];
  timestamps: number[];
};
