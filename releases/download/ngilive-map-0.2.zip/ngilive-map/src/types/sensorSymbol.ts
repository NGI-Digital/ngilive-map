export type sensorSymbol = {
  type: string;
  markerType: string;
  image?: string;
  color: string;
  size: number;
};
